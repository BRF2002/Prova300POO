package ex1;

public class Main {

	public static void main(String[] args) {

		Aluno Aluno = new Aluno(0, 0);
		
		Pessoa Pessoa = new Pessoa(0, 0);

	}

}
